# Problems summary

## Expected

## Environment Information
 * OS:
 * Vim version:

## Minimal vimrc less than 50 lines

  " Your vimrc
  set nocompatible

  set runtimepath+=~/path/to/neocomplete.vim/

  set fo+=aw
  let g:neocomplete#enable_at_startup = 1
  let g:neocomplete#enable_auto_select = 0
  set tw=10 " just for testing purposes

## Reproducable ways from Vim starting

 1.
 2.
 3.

## Screen shot (if possible)
