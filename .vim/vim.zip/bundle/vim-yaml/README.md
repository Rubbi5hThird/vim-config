Vim Yaml
========

Syntax file from [http://www.vim.org/scripts/script.php?script_id=739](http://www.vim.org/scripts/script.php?script_id=739)

Yaml files in vim 7.4 are really slow, due to core yaml syntax. This syntax is simpler/faster.
